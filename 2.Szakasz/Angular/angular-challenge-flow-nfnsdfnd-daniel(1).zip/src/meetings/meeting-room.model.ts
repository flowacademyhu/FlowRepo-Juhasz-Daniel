export class MeetingRoom {
    constructor(public name: string) {}
}